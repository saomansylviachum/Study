package com.fdmgroup.Strategy;

public class FlyNoWay implements FlyBehaviour{

	@Override
	public void fly() {
		System.out.println("Cannot fly...");
		
	}

}

package com.fdmgroup.Strategy;

public class Test {
	public static void main(String[] args) {
		Duck mallarDuck=new MallarDuck();
		mallarDuck.display();
		mallarDuck.performFly();
		mallarDuck.performQuack();
	}
	
	

}

package com.fdmgroup.Strategy;

public interface QuackBehaviour {
	void quack();
}

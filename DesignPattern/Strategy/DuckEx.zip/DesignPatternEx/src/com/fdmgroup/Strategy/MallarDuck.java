package com.fdmgroup.Strategy;

public class MallarDuck extends Duck{
	public MallarDuck() {
		setFlyBehaviour(new FlyWithWings());
		setQuackBehaviour(new Quack());
	}
	@Override
	public void display() {
		System.out.println("I'm mallar Duck.");
		
	}

}

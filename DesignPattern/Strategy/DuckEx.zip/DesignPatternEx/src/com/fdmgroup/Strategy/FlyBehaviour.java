package com.fdmgroup.Strategy;

public interface FlyBehaviour {
	void fly();
}

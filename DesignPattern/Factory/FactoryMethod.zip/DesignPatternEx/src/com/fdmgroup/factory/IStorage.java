package com.fdmgroup.factory;

import java.util.List;

public interface IStorage {
	void create(User user);
	User read(int id);
	List<User> readAll();
	void update(User updatedUser);
	void delete(int id);
}

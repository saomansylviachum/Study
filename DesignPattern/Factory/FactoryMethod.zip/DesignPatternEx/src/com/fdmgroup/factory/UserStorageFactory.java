package com.fdmgroup.factory;

public class UserStorageFactory implements IStorageFactory{

	@Override
	public IStorage getStorage() {
		return new UserArrayListStorage();
	}

}

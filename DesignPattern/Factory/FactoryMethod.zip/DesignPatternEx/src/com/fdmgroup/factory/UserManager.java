package com.fdmgroup.factory;

public class UserManager {
	public static void main(String[] args) {
		UserStorageFactory userStorageFactory=new UserStorageFactory();
		IStorage userIStorage=userStorageFactory.getStorage();
		userIStorage.create(new User(2));
		userIStorage.delete(2);
	}
}

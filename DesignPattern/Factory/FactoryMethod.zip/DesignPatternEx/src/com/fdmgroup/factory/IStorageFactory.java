package com.fdmgroup.factory;

public interface IStorageFactory {
	IStorage getStorage();
}

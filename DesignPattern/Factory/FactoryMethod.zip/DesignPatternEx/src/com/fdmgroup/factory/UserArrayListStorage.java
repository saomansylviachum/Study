package com.fdmgroup.factory;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class UserArrayListStorage implements IStorage{
	private List<User> users=new ArrayList<User>();
	@Override
	public void create(User user) {
		users.add(user);
		
	}

	@Override
	public User read(int id) {
		for (User user : users) {
			if(user.getId()==id)
				return user;
		}
		return null;
	}

	@Override
	public List<User> readAll() {
		// TODO Auto-generated method stub
		return users;
	}

	@Override
	public void update(User updatedUser) {
		for (int i = 0; i < users.size(); i++) {
			if(users.get(i).getId()==updatedUser.getId())
				{
				users.set(i, updatedUser);
				break;
				}
		}
		
		
	}

	@Override
	public void delete(int id) {
		Iterator<User> iterator=users.iterator();
		while (iterator.hasNext()) {
			if (iterator.next().getId()==id) {
				users.remove(users);
				break;
			}
		}
		
	}
	public static void main(String[] args) {
		UserArrayListStorage userArrayListStorage=new UserArrayListStorage();
		for (int i = 0; i < 10; i++) {
			userArrayListStorage.create(new User(i));
		}
		userArrayListStorage.update(new User(2));
		userArrayListStorage.delete(2);
	}

}
